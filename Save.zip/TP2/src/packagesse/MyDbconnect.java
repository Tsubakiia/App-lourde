package packagesse;
import java.sql.*;
import java.awt.*;
import java.awt.event.*;
public class MyDbconnect {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/situation lourde java","root","");
			System.out.println("Connexion avec la BDD établie");
			
			
		}
		catch(SQLException e) {
			System.out.println("Erreur avec la connexion");
		}

	}

}
