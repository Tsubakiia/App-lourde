package packagesse;

import java.util.Random;



public class Personne {
	private String nom;
	private int age;
	private int Nsecu;
	private char Sexe;
	private double poids;
	private double taille;

	

	public Personne(String nom, int age, char c, double poids, double taille) {
		super();
		this.nom = nom;
		this.age = age;
		
		Sexe = c;
		this.poids = poids;
		this.taille = taille;
	}
	public Personne(java.lang.String nom, int age, char sexe) {
		super();
		this.nom = nom;
		this.age = age;
		Sexe = sexe;}

	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getNsecu() {
		return Nsecu;
	}
	public String getSexe() {
		String sexes =String.valueOf(Sexe);
		return sexes;
	}
	public void setSexe(char sexe) {
		Sexe = sexe;
		
	}
	public double getPoids() {
		return poids;
	}
	public void setPoids(double poids) {
		this.poids = poids;
	}
	public double getTaille() {
		return taille;
	}
	public void setTaille(double taille) {
		this.taille = taille;
	}
	
	public int calculerIMC(){
		//Récupération du poids et le taille entrés en input et calcul de l'IMC
		int Imc = (int) (getPoids()/Math.pow(getTaille(),2));
		
		if(Imc<20) {
			//Affichage du poids idéal en fonction de la taille et du poids
			System.out.println("Le poids est en dessous du poinds idéal, votre IMC est "+Imc);
		}
		else if(Imc >= 20 && Imc <= 25) {
			System.out.println("Le poids est idéal, votre IMC est "+Imc);
		}
		else if(Imc > 25) {
			System.out.println("Le poids est au dessus du poids idéal (Obésité), votre IMC est "+Imc);
		}
		return Imc;
	}
	public String isOlderAge(){
		boolean maj;
		String Reponse;
		//Vérification de la majorité de la Personne
			if(getAge()>=18) {
				 maj = true;
				Reponse = "Vous êtes majeur";
			}
			else {
				maj = false;
				Reponse = "Vous êtes mineur";
			}

			
			return Reponse ;
	}

protected String genererNsecu() {
	//Generation d'un nombre aléatoire
	double N = Math.random();
	int d = (int)N;
	d=(int)(Math.random()*100000000);
	
	//Génération d'une lettre aléatoire
	Random rand = new Random();
	char car = (char)(rand.nextInt(26)+97);
	//Conversion de la concatenation des 8 chiffres et de la lettre en String
	System.out.println("Votre numéro de sécu est "+d+""+car);
	String Nsecu=String.valueOf(d) + String.valueOf(car);
	
	return Nsecu;
	
}
@Override
public String toString() {
	return "Personne [nom=" + nom + ", age=" + age + ", Nsecu=" + Nsecu + ", Sexe=" + Sexe + ", poids=" + poids
			+ ", taille=" + taille + "]";
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
