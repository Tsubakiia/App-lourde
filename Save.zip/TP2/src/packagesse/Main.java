package packagesse;
import java.util.Scanner;
import packagesse.MyDbconnect;
import java.sql.*;
import java.awt.*;
import java.awt.event.*;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
public class Main extends WindowAdapter {
	static String insertQuery;
	public static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame f;
		f=new JFrame();
		String nom = JOptionPane.showInputDialog("Entrez votre nom");
		String ages = JOptionPane.showInputDialog("Entrez votre age");
		String sexes = JOptionPane.showInputDialog("Entrez votre sexe");
		String masse = JOptionPane.showInputDialog("Entrez votre poids");
		String taillem = JOptionPane.showInputDialog("Entrez votre taille (en m)");
						
		Personne p1 = new Personne(nom,(Integer.parseInt(ages)),sexes.charAt(0),(Double.parseDouble(masse)),Double.parseDouble(taillem));
		
		JOptionPane.showMessageDialog(f,"Bonjour "+p1.getNom()+" ! "+" "+p1.isOlderAge()+
		" "+" "+"Votre Imc est de "+p1.calculerIMC()+" "+"Voici Votre numéro de Sécurité Sociale "+p1.genererNsecu());
		f.addWindowListener(null);
		f.setSize(300,300);
		f.setLayout(null);
		f.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		f.setVisible(true);
		int a =JOptionPane.showConfirmDialog(f,"Voulez-vous enregistrer vos données ?");
		if(a==JOptionPane.YES_OPTION) {
			f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		String NumSec=p1.genererNsecu();
		System.out.println("Affichage du numéro de Sécu"+NumSec);
		try {
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/situation lourde java","root","");
		System.out.println("Connexion avec la BDD établie");

		insertQuery = "INSERT INTO Personne(nom,age,Nsecu,Imc,Sexe,Poids,Taille)"+"VALUES(?,?,?,?,?,?,?)";
		Class.forName(JDBC_DRIVER);
		PreparedStatement pst = con.prepareStatement(insertQuery);
		pst.setString(1,p1.getNom() );
		pst.setInt(2, p1.getAge());
		pst.setString(3, p1.genererNsecu());
		pst.setDouble(4, p1.calculerIMC());
		pst.setString(5, p1.getSexe());
		pst.setDouble(6, p1.getPoids());
		pst.setDouble(7, p1.getTaille());
		pst.executeUpdate();


		
		pst.close();
		con.close();

		}
		catch(ClassNotFoundException e1) {
			e1.printStackTrace();
		}catch(SQLException e1) {
			e1.printStackTrace();
		}
		
		}
	}

}
