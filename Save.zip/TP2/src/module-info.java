/**
 * 
 */
/**
 * @author Lucas
 *
 */
module TP2 {
	requires java.desktop;
	requires java.sql;
}